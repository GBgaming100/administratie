

$(document).ready(function () {
    window.setTimeout(function(){

        // Move to a new location or you can do something else
        window.location.href = "/Administratie/index.php";

    }, 5500);

});